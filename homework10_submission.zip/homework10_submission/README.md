# INS3064 - Homework 10: Contact Manager (PHP + MySQL)

Ứng dụng quản lý danh bạ với đầy đủ CRUD, dùng PHP, MySQL và PDO prepared statements.

## Homework 10 demo

Video demo: **DÁN_LINK_VIDEO_YOUTUBE_HOẶC_GOOGLE_DRIVE_VÀO_ĐÂY**

## Cấu trúc

```
contact_manager/
├── setup.sql      # tạo database, bảng contacts, 6 dữ liệu mẫu
├── config.php     # kết nối PDO + session
├── functions.php  # hàm dùng chung (escape, flash, CSRF, validate)
├── header.php     # phần đầu trang dùng chung
├── footer.php     # phần cuối trang dùng chung
├── _form.php      # form dùng chung cho add/edit
├── index.php      # danh sách + tìm kiếm + sắp xếp
├── add.php        # thêm liên hệ
├── edit.php       # sửa liên hệ
├── delete.php     # xác nhận + xóa liên hệ
└── style.css      # giao diện
```

## Cách chạy

1. Chép thư mục `contact_manager/` vào `htdocs/INS3064/` (XAMPP).
2. Import `contact_manager/setup.sql` bằng phpMyAdmin.
3. Mở `http://localhost/INS3064/contact_manager/`.
4. Nếu MySQL không dùng `root` với mật khẩu trống, sửa hằng số trong `config.php`.

## Tính năng

- Thêm / sửa / xóa liên hệ, flash message sau mỗi thao tác
- Kiểm tra dữ liệu phía server (tên bắt buộc, email hợp lệ và không trùng)
- Form giữ lại giá trị đã nhập khi có lỗi
- Trang xác nhận trước khi xóa, chỉ xóa khi gửi POST
- Tìm kiếm theo tên hoặc email, sắp xếp bằng cách bấm tiêu đề cột
- Toàn bộ truy vấn dùng PDO prepared statements, output dùng `htmlspecialchars()`
- Giao diện responsive
