<?php
/**
 * index.php - Trang danh sách liên hệ (READ)
 * - Tổng số liên hệ
 * - Tìm kiếm theo name hoặc email (form GET, giữ lại từ khóa)
 * - Sắp xếp bằng cách bấm vào tiêu đề cột (whitelist cột)
 */
require_once __DIR__ . '/config.php';

// ----- 1. Đọc tham số tìm kiếm / sắp xếp -----
$search = trim((string) filter_input(INPUT_GET, 'q', FILTER_UNSAFE_RAW));

// Whitelist: tên tham số => tên cột thật (không thể bind tên cột bằng placeholder)
$sortableColumns = [
    'name'    => 'name',
    'email'   => 'email',
    'phone'   => 'phone',
    'group'   => 'group_name',
    'created' => 'created_at',
];
$sortKey = filter_input(INPUT_GET, 'sort', FILTER_UNSAFE_RAW);
if (!is_string($sortKey) || !isset($sortableColumns[$sortKey])) {
    $sortKey = 'created';
}
$dir = strtolower((string) filter_input(INPUT_GET, 'dir', FILTER_UNSAFE_RAW)) === 'asc' ? 'asc' : 'desc';

$orderColumn    = $sortableColumns[$sortKey];   // an toàn: lấy từ whitelist
$orderDirection = strtoupper($dir);             // an toàn: chỉ ASC hoặc DESC

// ----- 2. Truy vấn -----
// Tổng số liên hệ (không phụ thuộc tìm kiếm)
$stmt = $pdo->prepare('SELECT COUNT(*) FROM contacts');
$stmt->execute();
$totalContacts = (int) $stmt->fetchColumn();

// Danh sách (có hoặc không có tìm kiếm)
$sql    = 'SELECT id, name, email, phone, group_name, created_at FROM contacts';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE name LIKE :search_name OR email LIKE :search_email';
    // Escape ký tự đặc biệt của LIKE (% _ \) để tìm đúng nghĩa đen
    $like = '%' . addcslashes($search, '%_\\') . '%';
    $params = ['search_name' => $like, 'search_email' => $like];
}
$sql .= " ORDER BY {$orderColumn} {$orderDirection}, id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$contacts = $stmt->fetchAll();

/** Tạo link sắp xếp cho tiêu đề cột; giữ nguyên từ khóa tìm kiếm. */
function sort_link(string $label, string $key, string $currentKey, string $currentDir, string $search): string
{
    $nextDir = ($key === $currentKey && $currentDir === 'asc') ? 'desc' : 'asc';
    $query   = http_build_query(['q' => $search, 'sort' => $key, 'dir' => $nextDir]);
    $arrow   = $key === $currentKey ? ($currentDir === 'asc' ? ' ▲' : ' ▼') : '';
    return '<a href="index.php?' . e($query) . '">' . e($label) . $arrow . '</a>';
}

$pageTitle = 'Contacts';
include __DIR__ . '/header.php';
?>

<div class="page-head">
    <div>
        <h1>Contacts</h1>
        <p class="muted">
            Total: <strong><?= $totalContacts ?></strong> contact<?= $totalContacts === 1 ? '' : 's' ?>
            <?php if ($search !== ''): ?>
                · Showing <strong><?= count($contacts) ?></strong> result<?= count($contacts) === 1 ? '' : 's' ?>
                for “<?= e($search) ?>”
            <?php endif; ?>
        </p>
    </div>
    <a href="add.php" class="btn btn-primary">+ Add New Contact</a>
</div>

<form method="get" action="index.php" class="search-form" role="search">
    <input type="search" name="q" placeholder="Search by name or email…"
           value="<?= e($search) ?>" aria-label="Search contacts">
    <input type="hidden" name="sort" value="<?= e($sortKey) ?>">
    <input type="hidden" name="dir" value="<?= e($dir) ?>">
    <button type="submit" class="btn btn-primary">Search</button>
    <?php if ($search !== ''): ?>
        <a href="index.php" class="btn btn-secondary">Clear</a>
    <?php endif; ?>
</form>

<?php if (empty($contacts)): ?>
    <div class="card empty">
        <?php if ($search !== ''): ?>
            <p>No contacts match “<?= e($search) ?>”.</p>
        <?php else: ?>
            <p>No contacts yet. <a href="add.php">Add your first contact</a>.</p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="table-wrap">
        <table class="contacts-table">
            <thead>
                <tr>
                    <th><?= sort_link('Name', 'name', $sortKey, $dir, $search) ?></th>
                    <th><?= sort_link('Email', 'email', $sortKey, $dir, $search) ?></th>
                    <th><?= sort_link('Phone', 'phone', $sortKey, $dir, $search) ?></th>
                    <th><?= sort_link('Group', 'group', $sortKey, $dir, $search) ?></th>
                    <th><?= sort_link('Created At', 'created', $sortKey, $dir, $search) ?></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td data-label="Name"><?= e($contact['name']) ?></td>
                        <td data-label="Email"><?= e($contact['email']) ?></td>
                        <td data-label="Phone"><?= e($contact['phone']) ?></td>
                        <td data-label="Group">
                            <span class="badge badge-<?= e(strtolower((string) $contact['group_name'])) ?>">
                                <?= e($contact['group_name']) ?>
                            </span>
                        </td>
                        <td data-label="Created At">
                            <?= e(date('d/m/Y H:i', strtotime($contact['created_at']))) ?>
                        </td>
                        <td data-label="Actions" class="actions">
                            <a href="edit.php?id=<?= (int) $contact['id'] ?>" class="btn btn-small btn-secondary">Edit</a>
                            <a href="delete.php?id=<?= (int) $contact['id'] ?>" class="btn btn-small btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/footer.php'; ?>
