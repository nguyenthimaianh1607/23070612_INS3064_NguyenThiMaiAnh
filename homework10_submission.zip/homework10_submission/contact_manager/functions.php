<?php
/**
 * functions.php
 * Các hàm dùng chung: escape HTML, flash message, CSRF, đọc + kiểm tra dữ liệu form.
 */

// Danh sách nhóm hợp lệ (dùng cho dropdown và kiểm tra server-side)
const CONTACT_GROUPS = ['Family', 'Friends', 'Work', 'Other', 'General'];

/** Escape dữ liệu trước khi in ra HTML (chống XSS). */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Lưu flash message vào session (hiển thị đúng 1 lần). */
function set_flash(string $message, string $type = 'success'): void
{
    $_SESSION['message']      = $message;
    $_SESSION['message_type'] = $type; // success | error | warning
}

/** In flash message (nếu có) rồi xóa khỏi session. */
function show_flash(): void
{
    if (empty($_SESSION['message'])) {
        return;
    }
    $type = in_array($_SESSION['message_type'] ?? '', ['success', 'error', 'warning'], true)
        ? $_SESSION['message_type']
        : 'success';

    echo '<div class="flash flash-' . $type . '" role="alert">'
        . e($_SESSION['message'])
        . '</div>';

    unset($_SESSION['message'], $_SESSION['message_type']);
}

/** Chuyển trang rồi dừng script. */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Tạo (hoặc lấy) CSRF token của session. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Input ẩn chứa CSRF token, đặt trong mọi form POST. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** Kiểm tra CSRF token gửi lên có khớp không. */
function csrf_valid(): bool
{
    $sent = filter_input(INPUT_POST, 'csrf_token', FILTER_UNSAFE_RAW) ?? '';
    return hash_equals($_SESSION['csrf_token'] ?? '', $sent);
}

/**
 * Đọc dữ liệu form từ $_POST bằng filter_input(), cắt khoảng trắng đầu/cuối.
 * Trả về mảng đủ các khóa để form luôn có giá trị (sticky form).
 */
function read_contact_input(): array
{
    $field = static function (string $key): string {
        $value = filter_input(INPUT_POST, $key, FILTER_UNSAFE_RAW);
        return trim((string) $value);
    };

    return [
        'name'       => $field('name'),
        'email'      => $field('email'),
        'phone'      => $field('phone'),
        'group_name' => $field('group_name'),
        'notes'      => $field('notes'),
    ];
}

/**
 * Kiểm tra dữ liệu liên hệ phía server.
 * @param int|null $ignoreId  id của contact đang sửa (bỏ qua khi kiểm tra trùng email)
 * @return array<string,string> mảng lỗi theo từng field (rỗng = hợp lệ)
 */
function validate_contact(PDO $pdo, array $data, ?int $ignoreId = null): array
{
    $errors = [];

    // Name: bắt buộc, tối đa 100 ký tự
    if ($data['name'] === '') {
        $errors['name'] = 'Name is required.';
    } elseif (mb_strlen($data['name']) > 100) {
        $errors['name'] = 'Name must be at most 100 characters.';
    }

    // Email: bắt buộc, đúng định dạng, không trùng
    if ($data['email'] === '') {
        $errors['email'] = 'Email is required.';
    } elseif (mb_strlen($data['email']) > 150) {
        $errors['email'] = 'Email must be at most 150 characters.';
    } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false) {
        $errors['email'] = 'Please enter a valid email address.';
    } else {
        $sql    = 'SELECT COUNT(*) FROM contacts WHERE email = :email AND id <> :id';
        $stmt   = $pdo->prepare($sql);
        $stmt->execute(['email' => $data['email'], 'id' => $ignoreId ?? 0]);
        if ((int) $stmt->fetchColumn() > 0) {
            $errors['email'] = 'This email is already used by another contact.';
        }
    }

    // Phone: tùy chọn, chỉ cho số, khoảng trắng, + - ( ) . và tối đa 20 ký tự
    if ($data['phone'] !== '') {
        if (mb_strlen($data['phone']) > 20) {
            $errors['phone'] = 'Phone must be at most 20 characters.';
        } elseif (!preg_match('/^[0-9+\-\s().]+$/', $data['phone'])) {
            $errors['phone'] = 'Phone may only contain digits, spaces and + - ( ) .';
        }
    }

    // Group: phải nằm trong danh sách cho phép
    if (!in_array($data['group_name'], CONTACT_GROUPS, true)) {
        $errors['group_name'] = 'Please choose a valid group.';
    }

    return $errors;
}

/** Lấy 1 contact theo id (null nếu không tồn tại). */
function find_contact(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM contacts WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return $row === false ? null : $row;
}

/** Đọc id từ query string, trả về int dương hoặc null. */
function get_id_from_query(): ?int
{
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return $id === false || $id === null ? null : $id;
}
