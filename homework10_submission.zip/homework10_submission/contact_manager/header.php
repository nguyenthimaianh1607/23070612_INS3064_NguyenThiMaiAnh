<?php
/**
 * header.php - phần đầu trang dùng chung.
 * Biến cần đặt trước khi include: $pageTitle (string)
 */
$pageTitle = $pageTitle ?? 'Contact Manager';
$current   = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?> · Contact Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="index.php">📇 Contact Manager</a>
        <nav class="main-nav" aria-label="Main">
            <a href="index.php" class="<?= $current === 'index.php' ? 'active' : '' ?>">Contacts</a>
            <a href="add.php" class="<?= $current === 'add.php' ? 'active' : '' ?>">Add New</a>
        </nav>
    </div>
</header>

<main class="container">
    <?php show_flash(); ?>
