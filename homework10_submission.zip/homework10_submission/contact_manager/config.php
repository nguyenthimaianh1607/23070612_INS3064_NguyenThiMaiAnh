<?php
/**
 * config.php
 * Contact Manager - INS3064 Homework 10
 *
 * Nhiệm vụ:
 *  - Khai báo hằng số kết nối CSDL
 *  - Tạo kết nối PDO dùng chung ($pdo)
 *  - Khởi động session (cho flash message + CSRF token)
 *  - Nạp các hàm tiện ích (functions.php)
 */

// ----- Thông số kết nối (sửa lại nếu máy bạn khác) -----
const DB_HOST = 'localhost';
const DB_NAME = 'contact_manager';
const DB_USER = 'root';
const DB_PASS = '';           // XAMPP mặc định để trống
const DB_CHARSET = 'utf8mb4';

// ----- Session: cần cho flash message -----
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ----- Kết nối PDO -----
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // ném exception khi có lỗi SQL
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // trả về mảng kết hợp
            PDO::ATTR_EMULATE_PREPARES   => false,                  // dùng prepared statement thật
        ]
    );
} catch (PDOException $e) {
    // Không in thông tin nhạy cảm; chỉ báo lỗi chung
    http_response_code(500);
    die('Database connection failed: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}

require_once __DIR__ . '/functions.php';
