<?php
/**
 * add.php - Thêm liên hệ mới (CREATE)
 * GET : hiển thị form trống
 * POST: kiểm tra dữ liệu -> INSERT -> flash + redirect; nếu lỗi thì hiện lại form (sticky)
 */
require_once __DIR__ . '/config.php';

$errors = [];
$values = [
    'name' => '', 'email' => '', 'phone' => '',
    'group_name' => 'General', 'notes' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        http_response_code(400);
        die('Invalid request (CSRF token mismatch).');
    }

    $values = read_contact_input();
    $errors = validate_contact($pdo, $values);

    if (empty($errors)) {
        $sql = 'INSERT INTO contacts (name, email, phone, group_name, notes)
                VALUES (:name, :email, :phone, :group_name, :notes)';
        $stmt = $pdo->prepare($sql);
        try {
            $stmt->execute([
                'name'       => $values['name'],
                'email'      => $values['email'],
                'phone'      => $values['phone'] !== '' ? $values['phone'] : null,
                'group_name' => $values['group_name'],
                'notes'      => $values['notes'] !== '' ? $values['notes'] : null,
            ]);
            set_flash('Contact added successfully!', 'success');
            redirect('index.php');
        } catch (PDOException $ex) {
            // 23000 = vi phạm UNIQUE (có người vừa thêm cùng email giữa lúc kiểm tra và INSERT)
            if ($ex->getCode() === '23000') {
                $errors['email'] = 'This email is already used by another contact.';
            } else {
                throw $ex;
            }
        }
    }
}

$pageTitle   = 'Add Contact';
$formAction  = 'add.php';
$submitLabel = 'Add Contact';
include __DIR__ . '/header.php';
?>

<div class="page-head">
    <h1>Add New Contact</h1>
</div>

<?php if (!empty($errors)): ?>
    <div class="flash flash-error" role="alert">Please fix the errors below and try again.</div>
<?php endif; ?>

<?php include __DIR__ . '/_form.php'; ?>

<?php include __DIR__ . '/footer.php'; ?>
