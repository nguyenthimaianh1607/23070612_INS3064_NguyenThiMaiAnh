<?php
/**
 * edit.php - Sửa liên hệ (UPDATE)
 * Nhận id qua query string (edit.php?id=3).
 * GET : nạp dữ liệu cũ vào form
 * POST: kiểm tra -> UPDATE -> flash + redirect; nếu lỗi thì hiện lại form
 */
require_once __DIR__ . '/config.php';

$id      = get_id_from_query();
$contact = $id !== null ? find_contact($pdo, $id) : null;

// ----- Không tìm thấy contact -----
if ($contact === null) {
    http_response_code(404);
    $pageTitle = 'Contact not found';
    include __DIR__ . '/header.php';
    ?>
    <div class="card empty">
        <h1>Contact not found</h1>
        <p>The contact you are trying to edit does not exist (it may have been deleted).</p>
        <a href="index.php" class="btn btn-primary">&larr; Back to contacts</a>
    </div>
    <?php
    include __DIR__ . '/footer.php';
    exit;
}

$errors = [];
// Giá trị ban đầu = dữ liệu trong DB
$values = [
    'name'       => (string) $contact['name'],
    'email'      => (string) $contact['email'],
    'phone'      => (string) $contact['phone'],
    'group_name' => (string) $contact['group_name'],
    'notes'      => (string) $contact['notes'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        http_response_code(400);
        die('Invalid request (CSRF token mismatch).');
    }

    $values = read_contact_input();
    $errors = validate_contact($pdo, $values, $id); // bỏ qua chính contact này khi check trùng email

    if (empty($errors)) {
        $sql = 'UPDATE contacts
                SET name = :name, email = :email, phone = :phone,
                    group_name = :group_name, notes = :notes
                WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        try {
            $stmt->execute([
                'name'       => $values['name'],
                'email'      => $values['email'],
                'phone'      => $values['phone'] !== '' ? $values['phone'] : null,
                'group_name' => $values['group_name'],
                'notes'      => $values['notes'] !== '' ? $values['notes'] : null,
                'id'         => $id,
            ]);
            set_flash('Contact updated successfully!', 'success');
            redirect('index.php');
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') {
                $errors['email'] = 'This email is already used by another contact.';
            } else {
                throw $ex;
            }
        }
    }
}

$pageTitle   = 'Edit Contact';
$formAction  = 'edit.php?id=' . $id;
$submitLabel = 'Save Changes';
include __DIR__ . '/header.php';
?>

<div class="page-head">
    <h1>Edit Contact</h1>
</div>

<?php if (!empty($errors)): ?>
    <div class="flash flash-error" role="alert">Please fix the errors below and try again.</div>
<?php endif; ?>

<?php include __DIR__ . '/_form.php'; ?>

<?php include __DIR__ . '/footer.php'; ?>
