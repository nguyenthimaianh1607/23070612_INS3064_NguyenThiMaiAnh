<?php
/**
 * _form.php - form dùng chung cho add.php và edit.php (tránh lặp code).
 * Biến cần có:
 *   $values      mảng giá trị hiện tại (name, email, phone, group_name, notes)
 *   $errors      mảng lỗi theo field
 *   $formAction  URL nhận POST
 *   $submitLabel chữ trên nút submit
 */
$error = static function (string $field) use ($errors): string {
    return isset($errors[$field])
        ? '<span class="field-error">' . e($errors[$field]) . '</span>'
        : '';
};
?>
<form method="post" action="<?= e($formAction) ?>" class="card form" novalidate>
    <?= csrf_field() ?>

    <div class="form-group <?= isset($errors['name']) ? 'has-error' : '' ?>">
        <label for="name">Name <span class="req">*</span></label>
        <input type="text" id="name" name="name" maxlength="100" required
               value="<?= e($values['name']) ?>">
        <?= $error('name') ?>
    </div>

    <div class="form-group <?= isset($errors['email']) ? 'has-error' : '' ?>">
        <label for="email">Email <span class="req">*</span></label>
        <input type="email" id="email" name="email" maxlength="150" required
               value="<?= e($values['email']) ?>">
        <?= $error('email') ?>
    </div>

    <div class="form-row">
        <div class="form-group <?= isset($errors['phone']) ? 'has-error' : '' ?>">
            <label for="phone">Phone</label>
            <input type="tel" id="phone" name="phone" maxlength="20"
                   value="<?= e($values['phone']) ?>">
            <?= $error('phone') ?>
        </div>

        <div class="form-group <?= isset($errors['group_name']) ? 'has-error' : '' ?>">
            <label for="group_name">Group</label>
            <select id="group_name" name="group_name">
                <?php foreach (CONTACT_GROUPS as $group): ?>
                    <option value="<?= e($group) ?>"
                        <?= $values['group_name'] === $group ? 'selected' : '' ?>>
                        <?= e($group) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?= $error('group_name') ?>
        </div>
    </div>

    <div class="form-group">
        <label for="notes">Notes</label>
        <textarea id="notes" name="notes" rows="4"><?= e($values['notes']) ?></textarea>
    </div>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary"><?= e($submitLabel) ?></button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>
