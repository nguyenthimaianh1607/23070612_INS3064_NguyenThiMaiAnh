<?php
/**
 * footer.php - phần cuối trang dùng chung.
 */
?>
</main>

<footer class="site-footer">
    <div class="container">
        <p>INS3064 · Homework 10 · PHP + MySQL (PDO) · &copy; <?= date('Y') ?></p>
    </div>
</footer>
</body>
</html>
