-- ============================================================
-- setup.sql - Contact Manager (INS3064 Homework 10)
-- Chạy file này trong phpMyAdmin (tab SQL / Import) hoặc:
--   mysql -u root < setup.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS contact_manager
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE contact_manager;

-- Xóa bảng cũ (nếu có) để chạy lại file này nhiều lần không bị lỗi
DROP TABLE IF EXISTS contacts;

CREATE TABLE contacts (
    id         INT          NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) UNIQUE,
    phone      VARCHAR(20),
    group_name VARCHAR(50)  DEFAULT 'General',
    notes      TEXT,
    created_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu mẫu (6 liên hệ)
INSERT INTO contacts (name, email, phone, group_name, notes) VALUES
    ('Nguyễn Văn An',   'an.nguyen@example.com',   '0901234567', 'Family',  'Anh trai, sinh nhật 12/03.'),
    ('Trần Thị Bình',   'binh.tran@example.com',   '0912345678', 'Friends', 'Bạn cùng lớp đại học.'),
    ('Lê Hoàng Cường',  'cuong.le@example.com',    '0923456789', 'Work',    'Trưởng nhóm dự án web.'),
    ('Phạm Thu Dung',   'dung.pham@example.com',   '0934567890', 'Work',    'Đồng nghiệp phòng thiết kế.'),
    ('Võ Minh Đức',     'duc.vo@example.com',      '0945678901', 'Friends', 'Hay đi cà phê cuối tuần.'),
    ('Đặng Ngọc Hà',    'ha.dang@example.com',     '0956789012', 'General', NULL);
