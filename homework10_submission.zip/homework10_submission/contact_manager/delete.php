<?php
/**
 * delete.php - Xóa liên hệ (DELETE)
 * GET : hiển thị trang xác nhận (KHÔNG xóa)
 * POST: mới thực hiện xóa -> tránh xóa nhầm do crawler / prefetch link
 */
require_once __DIR__ . '/config.php';

$id      = get_id_from_query();
$contact = $id !== null ? find_contact($pdo, $id) : null;

// ----- Không tìm thấy -----
if ($contact === null) {
    // Nếu là POST (đã bị xóa từ tab khác) thì báo bằng flash rồi quay về danh sách
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        set_flash('That contact no longer exists.', 'warning');
        redirect('index.php');
    }
    http_response_code(404);
    $pageTitle = 'Contact not found';
    include __DIR__ . '/header.php';
    ?>
    <div class="card empty">
        <h1>Contact not found</h1>
        <p>The contact you are trying to delete does not exist.</p>
        <a href="index.php" class="btn btn-primary">&larr; Back to contacts</a>
    </div>
    <?php
    include __DIR__ . '/footer.php';
    exit;
}

// ----- POST: thực hiện xóa -----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        http_response_code(400);
        die('Invalid request (CSRF token mismatch).');
    }

    $stmt = $pdo->prepare('DELETE FROM contacts WHERE id = :id');
    $stmt->execute(['id' => $id]);

    set_flash('Contact “' . $contact['name'] . '” was deleted.', 'success');
    redirect('index.php');
}

// ----- GET: trang xác nhận -----
$pageTitle = 'Delete Contact';
include __DIR__ . '/header.php';
?>

<div class="page-head">
    <h1>Delete Contact</h1>
</div>

<div class="card confirm-box">
    <p class="confirm-question">Are you sure you want to delete this contact?</p>

    <dl class="details">
        <dt>Name</dt>
        <dd><?= e($contact['name']) ?></dd>
        <dt>Email</dt>
        <dd><?= e($contact['email']) ?></dd>
        <dt>Phone</dt>
        <dd><?= e($contact['phone']) ?: '—' ?></dd>
        <dt>Group</dt>
        <dd><?= e($contact['group_name']) ?></dd>
        <dt>Notes</dt>
        <dd><?= e($contact['notes']) ?: '—' ?></dd>
        <dt>Created</dt>
        <dd><?= e(date('d/m/Y H:i', strtotime($contact['created_at']))) ?></dd>
    </dl>

    <p class="warning-text">This action cannot be undone.</p>

    <form method="post" action="delete.php?id=<?= (int) $contact['id'] ?>" class="form-actions">
        <?= csrf_field() ?>
        <button type="submit" class="btn btn-danger">Yes, delete</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php include __DIR__ . '/footer.php'; ?>
