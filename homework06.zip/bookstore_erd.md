# Homework 6 — Online Bookstore ERD

**Student:** Nguyễn Thị Mai Anh  
**Student ID:** 23070612  
**Date:** 2026-10-18  
**Database:** `bookstore_db`  
**Matching implementation:** `bookstore_db.sql`

## 1. Relationship overview (text ERD)

`1` = exactly one; `0..1` = optional one; `0..N` = zero or many.
A child FK row always points to one parent unless the FK is explicitly nullable.

```text
publishers (1) -------- (0..N) books

books (1) ------------ (0..N) book_authors (0..N) ------------ (1) authors
         books <---------------- M:N ----------------> authors

books (1) ------------ (0..N) book_categories (0..N) --------- (1) categories
         books <---------------- M:N ----------------> categories

categories [parent] (0..1) ---- (0..N) categories [child]
                             parent_category_id

customers (1) -------- (0..N) orders
orders (1) ----------- (0..N) order_items (0..N) ------------- (1) books
         orders <--------------- M:N ----------------> books

customers (1) -------- (0..N) reviews (0..N) ----------------- (1) books
```

A book may have multiple authors and multiple categories; neither is encoded as
a list in a single column. A catalog draft may initially have no associations;
all sample books have at least one author and one category. Each junction row
contains exactly one valid key from each endpoint. The two junction PKs prohibit
duplicates. `order_items` additionally records quantity and the sale price.
There is no 1:1 relationship required by this design.

## 2. Complete entities and attributes

**PK** = primary key; **FK** = foreign key; **UQ** = unique candidate key; **AI** = auto-increment.
A composite PK is the combination of the marked fields, not each field separately.
All columns are NOT NULL except those explicitly marked nullable below.

### `authors`

One row per author; names are not assumed to be unique.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `author_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `full_name` | `VARCHAR(120)` | — | NOT NULL |
| `biography` | `TEXT` | — | Nullable |
| `nationality` | `VARCHAR(60)` | — | NOT NULL |

### `publishers`

Publisher details are stored once and referenced by books.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `publisher_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `publisher_name` | `VARCHAR(150)` | UQ | NOT NULL |
| `address_line` | `VARCHAR(200)` | — | NOT NULL |
| `city` | `VARCHAR(80)` | — | NOT NULL |
| `country` | `VARCHAR(80)` | — | NOT NULL; default 'Vietnam' |
| `website` | `VARCHAR(255)` | — | Nullable |

### `categories`

Optional parent_category_id represents sub-genres; NULL means a root category.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `category_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `category_name` | `VARCHAR(80)` | UQ | NOT NULL |
| `description` | `TEXT` | — | Nullable |
| `parent_category_id` | `INT UNSIGNED` | FK → `categories.category_id` | Nullable |

### `books`

One catalog row per ISBN/edition; the catalog price is the current price in VND.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `book_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `isbn` | `VARCHAR(13)` | UQ | NOT NULL |
| `title` | `VARCHAR(200)` | — | NOT NULL |
| `publisher_id` | `INT UNSIGNED` | FK → `publishers.publisher_id` | NOT NULL |
| `price` | `DECIMAL(12,2)` | — | NOT NULL; current catalog price, VND |
| `stock` | `INT` | — | NOT NULL; default 0 |
| `publication_date` | `DATE` | — | NOT NULL |
| `description` | `TEXT` | — | Nullable |

### `book_authors`

Resolves books M:N authors. The composite PK prevents duplicate associations.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `book_id` | `INT UNSIGNED` | PK, FK → `books.book_id` | NOT NULL |
| `author_id` | `INT UNSIGNED` | PK, FK → `authors.author_id` | NOT NULL |

Composite primary key: `(book_id, author_id)`.

### `book_categories`

Resolves books M:N categories. The composite PK prevents duplicate associations.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `book_id` | `INT UNSIGNED` | PK, FK → `books.book_id` | NOT NULL |
| `category_id` | `INT UNSIGNED` | PK, FK → `categories.category_id` | NOT NULL |

Composite primary key: `(book_id, category_id)`.

### `customers`

Customer profile and password hash; no plaintext password is stored.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `customer_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `full_name` | `VARCHAR(120)` | — | NOT NULL |
| `email` | `VARCHAR(150)` | UQ | NOT NULL |
| `password_hash` | `VARCHAR(255)` | — | NOT NULL; salted PBKDF2-SHA256, never plaintext |
| `address_line` | `VARCHAR(200)` | — | NOT NULL |
| `city` | `VARCHAR(80)` | — | NOT NULL |
| `country` | `VARCHAR(80)` | — | NOT NULL; default 'Vietnam' |
| `created_at` | `DATETIME` | — | NOT NULL; default CURRENT_TIMESTAMP |

### `orders`

Order header. Shipping fields are a snapshot of this order destination, not the current customer address.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `order_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `customer_id` | `INT UNSIGNED` | FK → `customers.customer_id` | NOT NULL |
| `order_date` | `DATETIME` | — | NOT NULL; default CURRENT_TIMESTAMP |
| `status` | `ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled')` | — | NOT NULL; default 'pending' |
| `shipping_address_line` | `VARCHAR(200)` | — | NOT NULL |
| `shipping_city` | `VARCHAR(80)` | — | NOT NULL |
| `shipping_country` | `VARCHAR(80)` | — | NOT NULL; default 'Vietnam' |

### `order_items`

One book per order. unit_price is the agreed historical price in VND, independent of books.price.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `order_id` | `INT UNSIGNED` | PK, FK → `orders.order_id` | NOT NULL |
| `book_id` | `INT UNSIGNED` | PK, FK → `books.book_id` | NOT NULL |
| `quantity` | `INT` | — | NOT NULL |
| `unit_price` | `DECIMAL(12,2)` | — | NOT NULL; historical sale price, VND |

Composite primary key: `(order_id, book_id)`.

### `reviews`

At most one review per customer and book. Customers may update an existing review.

| Attribute | Type | Keys / reference | Nullability, default and meaning |
|---|---|---|---|
| `review_id` | `INT UNSIGNED` | PK, AI | NOT NULL |
| `customer_id` | `INT UNSIGNED` | FK → `customers.customer_id` | NOT NULL |
| `book_id` | `INT UNSIGNED` | FK → `books.book_id` | NOT NULL |
| `rating` | `TINYINT` | — | NOT NULL |
| `comment` | `TEXT` | — | NOT NULL |
| `review_date` | `DATETIME` | — | NOT NULL; default CURRENT_TIMESTAMP |

Additional candidate key: `UNIQUE(customer_id, book_id)`; one review per customer/book pair.

## 3. Derived amounts (required subtotal and total)

The brief lists `subtotal` for order lines and `total` for order headers. These
attributes are present in the reporting views below and are deliberately not
stored as independently editable columns in the ten normalized base tables.
This resolves the brief's simultaneous requirements for monetary totals and 3NF
without storing redundant amounts that can become inconsistent.

| Object | Attributes | Source / formula |
|---|---|---|
| `v_order_items` (view) | `order_id`, `book_id`, `quantity`, `unit_price`, **`subtotal`** | All four base fields plus `quantity * unit_price` |
| `v_orders` (view) | `order_id`, `customer_id`, `order_date`, `status`, `shipping_address_line`, `shipping_city`, `shipping_country`, **`total`** | All order header fields plus `SUM(subtotal)` for that order |

Both monetary results are `DECIMAL(15,2)`. An empty draft order has total `0.00`.
These views add no tables or stored duplicates. To see the full order information
including amounts, browse `v_orders` and `v_order_items` in phpMyAdmin. The base
`orders` and `order_items` tables remain the authoritative data to insert/update.

```sql
SELECT * FROM v_order_items ORDER BY order_id, book_id;
SELECT * FROM v_orders ORDER BY order_id;
```

## 4. Cardinalities and foreign-key actions

| Parent | Child | Child FK | Cardinality | Meaning |
|---|---|---|---|---|
| publishers | books | `publisher_id` | 1 : 0..N | Each book has exactly one publisher. |
| categories (parent) | categories (child) | `parent_category_id` | 0..1 : 0..N | Each category has zero or one parent; a parent has zero or many children. |
| books | book_authors | `book_id` | 1 : 0..N | Each link belongs to exactly one book. |
| authors | book_authors | `author_id` | 1 : 0..N | Each link belongs to exactly one author. |
| books | book_categories | `book_id` | 1 : 0..N | Each link belongs to exactly one book. |
| categories | book_categories | `category_id` | 1 : 0..N | Each link belongs to exactly one category. |
| customers | orders | `customer_id` | 1 : 0..N | Each order has exactly one customer. |
| orders | order_items | `order_id` | 1 : 0..N | A draft may have zero lines; a confirmed order must have at least one. |
| books | order_items | `book_id` | 1 : 0..N | Each order line refers to exactly one book. |
| customers | reviews | `customer_id` | 1 : 0..N | Each review has exactly one customer. |
| books | reviews | `book_id` | 1 : 0..N | Each review has exactly one book. |

All foreign keys use `ON UPDATE CASCADE`. Delete behavior:

- **RESTRICT:** publisher → books; parent category → child categories; customer → orders;
  book → order_items. Referenced catalog and transaction identities must remain valid.
- **CASCADE:** book/author → book_authors; book/category → book_categories;
  order → order_items; customer/book → reviews. Dependent rows have no independent meaning.
- A nullable root-category parent is intentionally represented by NULL. Parent deletion
  is restricted, so deleting a category cannot silently detach its sub-genres.

## 5. Why this design satisfies 3NF

### First Normal Form

Each cell holds one value. Authors and categories are rows in junction tables,
not comma-separated fields. Addresses have separate address-line, city and country
fields. No repeated author1/author2 or book1/book2 columns exist.

### Second Normal Form

All non-key attributes depend on an entire candidate key. The two book junctions
contain only their composite keys. In `order_items`, the key is `(order_id, book_id)`;
quantity and historical unit price describe that book in that particular order.
A book can sell at different prices in different orders, so `book_id` alone does
not determine `unit_price`. All other tables use one-column surrogate primary keys.

### Third Normal Form

No non-key fact determines another stored non-key fact within a base table.
For example, `books` contains `publisher_id`, but the publisher's name, address and
website belong only to `publishers`. Repeating those details in `books` would create
`book_id → publisher_id → publisher details`, a transitive dependency.
The same separation is applied to authors, categories, customers and reviews.
Calculated subtotals/totals are supplied by views rather than redundant stored fields.

The order shipping address is a historical destination, not the customer's current
profile address. Order 4 goes to a different address from customer 1's profile.
The agreed unit price is similarly historical: book 1 currently costs 180,000 VND,
but order 1 purchased it for 175,000 VND. These are different business facts.

## 6. Constraints and assumptions

- ISBN is unique and must have 13 digits; sample check digits are valid. The database
  checks the format; the sample-data verification additionally checks the checksum.
- Publisher and category names are unique; author/customer names need not be unique.
- Customer email is unique; only salted password hashes are stored. Sample credentials
  are synthetic with discarded random input passwords; this homework is not a login app.
- Book price and sale price must be positive; stock cannot be negative; quantity must
  be positive; review rating is between 1 and 5.
- Defaults cover zero stock, pending order status, Vietnam and creation timestamps.
- All ten tables use InnoDB, utf8mb4 and utf8mb4_unicode_ci.
- Amounts use VND; this model assumes free delivery and no additional tax/discount.
- Confirmed orders require at least one item as an application workflow rule. A draft
  can be temporarily empty while a header and its items are inserted in a transaction.
- Parent categories must form a tree. The FK enforces parent existence, not cycle
  detection; an application must reject cycles. Sample category data is acyclic.
- One ISBN denotes one edition. An order contains at most one line per book;
  ordering multiple copies changes quantity. Reviews are not restricted to verified
  purchases by the schema; the sample reviews all refer to delivered purchases.
- All sample identities, books, publishers, addresses and ISBNs are illustrative.

## 7. Sample data and demonstrations

| Table | Required minimum | Included |
|---|---:|---:|
| `authors` | 6 | 6 |
| `publishers` | 4 | 4 |
| `categories` | 5 | 6 |
| `books` | 8 | 8 |
| `book_authors` | Not specified | 12 |
| `book_categories` | Not specified | 10 |
| `customers` | 5 | 5 |
| `orders` | 6 | 6 |
| `order_items` | 12 | 15 |
| `reviews` | 10 | 10 |

Examples that demonstrate the relationships:

- **Books ↔ authors:** book 1 has authors 1 and 2; author 2 writes books 1, 2 and 7.
- **Books ↔ categories:** book 7 belongs to Technology and Business; Technology has
  books 1, 2 and 7. Book 6 belongs to Children Fiction and Nature.
- **Category hierarchy:** Non-fiction is parent to Technology, Business and Nature;
  Fiction is parent to Children Fiction.
- **Customer ↔ orders:** customer 1 has orders 1 and 4, with different destinations.
- **Order ↔ books:** order 1 has three different books; book 1 appears in orders 1 and 3.
- **Reviews:** book 1 has reviews from customers 1 and 3; customer 1 reviews several books.
- **Useful edge cases:** book 8 currently has zero stock; order 6 is pending;
  order 5 is shipped; older order prices can differ from current catalog prices.

| Order | Expected total (VND) |
|---|---:|
| 1 | 675,000.00 |
| 2 | 435,000.00 |
| 3 | 585,000.00 |
| 4 | 235,000.00 |
| 5 | 620,000.00 |
| 6 | 270,000.00 |

## 8. Running the matching SQL

Open phpMyAdmin, select `bookstore_db`, and import `bookstore_db.sql` with UTF-8 encoding.
On a fresh server, first create an empty `bookstore_db` database with utf8mb4_unicode_ci. The script creates
`bookstore_db`, ten base tables, two views, all sample records and final checks.
Re-importing resets these homework tables and views, so back up edits first.
It never drops another database. The final SELECT statements check row counts and order totals; phpMyAdmin may
show only its import-success banner. Browse the tables/views to inspect the data.
Keep this database for Homework 7.
